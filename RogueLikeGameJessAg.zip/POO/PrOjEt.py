import copy 
import math
import random
from tkinter import *

#exceptions
def sign(x):
    if x > 0:
        return 1
    return -1


class Coord(object):
    """Implementation of a map coordinate"""

    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

    def __repr__(self):
        return '<' + str(self.x) + ',' + str(self.y) + '>'

    def __add__(self, other):
        return Coord(self.x + other.x, self.y + other.y)

    def __sub__(self, other):
        return Coord(self.x - other.x, self.y - other.y)

    def distance(self, other):
        """Returns the distance between two coordinates."""
        d = self - other
        return math.sqrt(d.x * d.x + d.y * d.y)

    cos45 = 1 / math.sqrt(2)

    def direction(self, other):
        """Returns the direction between two coordinates."""
        d = self - other
        cos = d.x / self.distance(other)
       
        if cos > Coord.cos45:
           if d.y < 0:
              return Coord(-1,1)
           if d.y > 0:
              return Coord(-1,-1)
           return Coord(-1, 0)
         
        elif cos < -Coord.cos45:
           if d.y>0:
              return Coord(1,-1)
           if d.y<0:
              return Coord(1,1)
           return Coord(1, 0)
         
        elif d.y > 0:
            return Coord(0, -1)
         
        return Coord(0, 1)


class Element(object):
    """Base class for game elements. Have a name.
        Abstract class."""

    def __init__(self, name, abbrv=""):
        self.name = name
        if abbrv == "":
            abbrv = name[0]
        self.abbrv = abbrv

    def __repr__(self):
        return self.abbrv

    def description(self):
        """Description of the element"""
        return "<" + self.name + ">"

    def meet(self, hero):
        """Makes the hero meet an element. Not implemented. """
        raise NotImplementedError('Abstract Element')


class Creature(Element):
    """A creature that occupies the dungeon.
        Is an Element. Has hit points and strength."""

    def __init__(self, name, hp, abbrv="", strength=1,XP=3):
        Element.__init__(self, name, abbrv)
        self.hp = hp
        self.strength = strength
        self.XP=XP
        

    def description(self):
        """Description of the creature"""
        return Element.description(self) + "(" + str(self.hp) + ")"

    def meet(self, other):
        """The creature is encountered by an other creature.
            The other one hits the creature. Return True if the creature is dead."""
        #checks the hero's equiment and uses armor or/and weapon if there is one
        if type(self)==Hero and theGame()._hero._equip!=[]:
            for i in theGame()._hero._equip:
                if type(i)==Armor:
                    i.useArmor(other)
                elif type(i)==Weapon:
                    i.useWeapon()
                    if self.hp-other.strength>=0:
                        self.hp-=other.strength
                        theGame().addMessage("The "+other.name+" hits the "+self.description())
                    else:
                        self.hp=0
                        theGame().addMessage("The "+other.name+" kills the "+self.description())
        else:
            if self.hp-other.strength>=0:
                self.hp-=other.strength
                theGame().addMessage("The "+other.name+" hits the "+self.description())
                if other.name=="Super Spider":
                    self.curse=True
                    theGame().addMessage("\nThe "+other.name+" has poisoned you, you must find an antidote !")
            else:
                self.hp=0
                theGame().addMessage("The "+other.name+" kills the "+self.description())
        if self.hp>0:
            return False 

        if type(other)==Hero:
            if other.XP+self.XP<=math.exp(other._lvl)*2:
                other.XP+=self.XP
            else:
                other.XP=math.exp(other._lvl)
            if other.XP>=math.exp(other._lvl):
               other.levelup()
               theGame().addMessage('level up !')
        return True



class Hero(Creature):
    """The hero of the game.
        Is a creature. Has an inventory of elements. """

    def __init__(self, name="Hero", hp=20, abbrv="@", strength=2,XP=0,lvl=1,curse=False):
        Creature.__init__(self, name, hp, abbrv, strength,XP)
        self._inventory = []
        self._gold=[]
        self._equip=[]
        self._lvl=lvl
        self._hpMAX=hp
        self.curse=curse

    def description(self):
        """Description of the hero"""
        return Creature.description(self) 

    def fullDescription(self):
        """Complete description of the hero"""
        res = ''
        for e in self.__dict__:
            if e[0] != '_':
                res += '> ' + e + ' : ' + str(self.__dict__[e]) + '\n'
        res += '> INVENTORY : ' + str([x.name for x in self._inventory])
        return res

    def checkEquipment(self, o):
        """Check if o is an Equipment."""
        if not isinstance(o, Equipment):
            raise TypeError('Not a Equipment')

    def take(self, elem):
        """The hero takes adds the equipment to its inventory"""
        self.checkEquipment(elem)
        if len(self._inventory)<=9 and elem.abbrv!="o":
            self._inventory.append(elem)

        if elem.abbrv=="o":
            self._gold.append(elem)


    def use(self, elem):
        """Use a piece of equipment"""
        if elem is None:
            return
        self.checkEquipment(elem)
        if elem not in self._inventory:
            raise ValueError('Equipment ' + elem.name + 'not in inventory')
        if elem.use(self):
            self._inventory.remove(elem)

    def levelup(self):
      self._lvl+=1
      self._hpMAX+=int(math.log(self._hpMAX+1)/2)
      self.hp=self._hpMAX
      self.strength+=int(math.log(self.strength+1))

class Equipment(Element):
    """A piece of equipment"""

    def __init__(self, name, abbrv="", usage=None):
        Element.__init__(self, name, abbrv)
        self.usage = usage

    def meet(self, hero):
        """Makes the hero meet an element. The hero takes the element."""
        hero.take(self)
        if len(theGame()._hero._inventory)<=10:
            theGame().addMessage("You pick up a " + self.name)
        else:
            theGame().addMessage("Your inventory is full, you cannot pickup the"+ self.name)
        return True

    def use(self, creature):
        """Uses the piece of equipment. Has effect on the hero according usage.
            Return True if the object is consumed."""
        if self.usage is None:
            theGame().addMessage("The " + self.name + " is not usable")
            return False
        else:
            theGame().addMessage("The " + creature.name + " uses the " + self.name)
            return self.usage(self, creature)

class Stairs(Element):
    """ Strairs that goes down one floor. """

    def __init__(self):
        super().__init__("Stairs", 'E')

    def meet(self, hero):
        """Goes down"""
        theGame().buildFloor()
        theGame().addMessage("The " + hero.name + " goes down. ")

class Boutique(Element):
   
    def __init__(self, name, abbrv="",):
        Element.__init__(self, name, abbrv)

    def meet(self,hero):
        theGame().buildFloorShop()
        theGame().addMessage("Hello "+ hero.name + ", welcome to the Dungeon shop ! How can I help ?")

def useInvent(event):
    if int(event.char) <len(theGame()._hero._inventory):
        theGame()._hero.use(theGame()._hero._inventory[int(event.char)])
        des.drawMap()

 
class Shopping(Element):
    def __init__(self, name, abbrv="",):
        Element.__init__(self, name, abbrv)

    def meet(self,hero):
        theGame().selectShop(Game.equipmentsList)
        

class Room(object):
    """A rectangular room in the map"""

    def __init__(self, c1, c2):
        self.c1 = c1
        self.c2 = c2

    def __repr__(self):
        return "[" + str(self.c1) + ", " + str(self.c2) + "]"

    def __contains__(self, coord):
        return self.c1.x <= coord.x <= self.c2.x and self.c1.y <= coord.y <= self.c2.y

    def intersect(self, other):
        """Test if the room has an intersection with another room"""
        sc3 = Coord(self.c2.x, self.c1.y)
        sc4 = Coord(self.c1.x, self.c2.y)
        return self.c1 in other or self.c2 in other or sc3 in other or sc4 in other or other.c1 in self

    def center(self):
        """Returns the coordinates of the room center"""
        return Coord((self.c1.x + self.c2.x) // 2, (self.c1.y + self.c2.y) // 2)

    def randCoord(self):
        """A random coordinate inside the room"""
        return Coord(random.randint(self.c1.x, self.c2.x), random.randint(self.c1.y, self.c2.y))

    def randEmptyCoord(self, map):
        """A random coordinate inside the room which is free on the map."""
        c = self.randCoord()
        while map.get(c) != Map.ground or c == self.center():
            c = self.randCoord()
        return c

    def randShop(self):
        rand=random.randint(1,15)
        if rand==9:
            return Boutique("Boutique")
        return None

    def decorate(self, map):
        """Decorates the room by adding a random equipment and monster."""
        map.put(self.randEmptyCoord(map), theGame().randEquipment())
        map.put(self.randEmptyCoord(map), theGame().randMonster())
        c=self.randShop()
        if c is not None:
            map.put(self.randEmptyCoord(map),c)


class Map(object):
    """A map of a game floor.
        Contains game elements."""

    ground = '.'  # A walkable ground cell
    dir = {'z': Coord(0, -1), 's': Coord(0, 1), 'd': Coord(1, 0), 'q': Coord(-1, 0)}  # four direction user keys
    empty = ' '  # A non walkable cell

    def __init__(self, size=20, hero=None,deco=None):
        self._mat = []
        self._elem = {}
        self._rooms = []
        self._roomsToReach = []
        for i in range(size):
            self._mat.append([Map.empty] * size)
        if hero is None:
            hero = Hero()
        self._hero = hero
        self.generateRooms(7)
        self.reachAllRooms()
        self.put(self._rooms[0].center(), hero)
        for r in self._rooms:
            if deco is None:
                r.decorate(self)

    def addRoom(self, room):
        """Adds a room in the map."""
        self._roomsToReach.append(room)
        for y in range(room.c1.y, room.c2.y + 1):
            for x in range(room.c1.x, room.c2.x + 1):
                self._mat[y][x] = Map.ground

    def findRoom(self, coord):
        """If the coord belongs to a room, returns the room elsewhere returns None"""
        for r in self._roomsToReach:
            if coord in r:
                return r
        return None

    def intersectNone(self, room):
        """Tests if the room shall intersect any room already in the map."""
        for r in self._roomsToReach:
            if room.intersect(r):
                return False
        return True

    def dig(self, coord):
        """Puts a ground cell at the given coord.
            If the coord corresponds to a room, considers the room reached."""
        self._mat[coord.y][coord.x] = Map.ground
        r = self.findRoom(coord)
        if r:
            self._roomsToReach.remove(r)
            self._rooms.append(r)

    def corridor(self, cursor, end):
        """Digs a corridors from the coordinates cursor to the end, first vertically, then horizontally."""
        d = end - cursor
        self.dig(cursor)
        while cursor.y != end.y:
            cursor = cursor + Coord(0, sign(d.y))
            self.dig(cursor)
        while cursor.x != end.x:
            cursor = cursor + Coord(sign(d.x), 0)
            self.dig(cursor)

    def reach(self):
        """Makes more rooms reachable.
            Start from one random reached room, and dig a corridor to an unreached room."""
        roomA = random.choice(self._rooms)
        roomB = random.choice(self._roomsToReach)

        self.corridor(roomA.center(), roomB.center())

    def reachAllRooms(self):
        """Makes all rooms reachable.
            Start from the first room, repeats @reach until all rooms are reached."""
        self._rooms.append(self._roomsToReach.pop(0))
        while len(self._roomsToReach) > 0:
            self.reach()

    def randRoom(self):
        """A random room to be put on the map."""
        c1 = Coord(random.randint(0, len(self) - 3), random.randint(0, len(self) - 3))
        c2 = Coord(min(c1.x + random.randint(3, 8), len(self) - 1), min(c1.y + random.randint(3, 8), len(self) - 1))
        return Room(c1, c2)

    def generateRooms(self, n):
        """Generates n random rooms and adds them if non-intersecting."""
        for i in range(n):
            r = self.randRoom()
            if self.intersectNone(r):
                self.addRoom(r)

    def __len__(self):
        return len(self._mat)

    def __contains__(self, item):
        if isinstance(item, Coord):
            return 0 <= item.x < len(self) and 0 <= item.y < len(self)
        return item in self._elem

    def __repr__(self):
        s = ""
        for i in self._mat:
            for j in i:
                s += str(j)
            s += '\n'
        return s

    def checkCoord(self, c):
        """Check if the coordinates c is valid in the map."""
        if not isinstance(c, Coord):
            raise TypeError('Not a Coord')
        if not c in self:
            raise IndexError('Out of map coord')

    def checkElement(self, o):
        """Check if o is an Element."""
        if not isinstance(o, Element):
            raise TypeError('Not a Element')

    def put(self, c, o):
        """Puts an element o on the cell c"""
        self.checkCoord(c)
        self.checkElement(o)
        if self._mat[c.y][c.x] != Map.ground:
            raise ValueError('Incorrect cell')
        if o in self._elem:
            raise KeyError('Already placed')
        self._mat[c.y][c.x] = o
        self._elem[o] = c

    def get(self, c):
        """Returns the object present on the cell c"""
        self.checkCoord(c)
        return self._mat[c.y][c.x]

    def pos(self, o):
        """Returns the coordinates of an element in the map """
        self.checkElement(o)
        return self._elem[o]

    def rm(self, c):
        """Removes the element at the coordinates c"""
        self.checkCoord(c)
        del self._elem[self._mat[c.y][c.x]]
        self._mat[c.y][c.x] = Map.ground

    def move(self, e, way):
        """Moves the element e in the direction way."""
        orig = self.pos(e)
        dest = orig + way
        if dest in self:
            if self.get(dest) == Map.ground:
                self._mat[orig.y][orig.x] = Map.ground
                self._mat[dest.y][dest.x] = e
                self._elem[e] = dest
            elif self.get(dest) != Map.empty and self.get(dest).meet(e) and self.get(dest) != self._hero:
                self.rm(dest)

    def moveAllMonsters(self):
        """Moves all monsters in the map.
            If a monster is at distance lower than 6 from the hero, the monster advances."""
        h = self.pos(self._hero)
        for e in self._elem:
            c = self.pos(e)
            if isinstance(e, Creature) and e != self._hero and c.distance(h) < 6:
                d = c.direction(h)
                if self.get(c + d) in [Map.ground, self._hero]:
                    self.move(e, d)

def heal(creature):
    """Heal the creature"""
    creature.hp += 3
    return True

def teleport(creature, unique):
    """Teleport the creature"""
    r = theGame()._floor.randRoom()
    c = r.randEmptyCoord(theGame()._floor)
    theGame()._floor.rm(theGame()._floor.pos(creature))
    theGame()._floor.put(c, creature)
    return unique

def antidote(person):
   """Heal hero from the poison"""
   if person.curse==True:
      person.curse=False
   return True

def equip(hero,equipment):
    "Equip the equipment"
    if hero._equip!=[]:
        for i in hero._equip:
            if type(i)==type(equipment):
                hero._inventory.append(i)
                hero._equip[hero._equip.index(i)]=equipment
            elif type(i)!=type(equipment):
                hero._equip.append(equipment)
                if type(equipment)==Weapon:
                    theGame()._hero.strength+=equipment.quality*equipment.strength
                return True
    else:
        hero._equip.append(equipment)
    if type(equipment)==Weapon:
        theGame()._hero.strength+=equipment.quality*equipment.strength
    return True

class Armor(Equipment):
    def __init__(self,name,abbrv="A",usage=None,life=5,quality=1):
        Equipment.__init__(self, name, abbrv,usage)
        self.life=life*quality
        self.quality=quality

    def useArmor(self,other):
        if self.life-other.strength>=0:
            self.life-=other.strength
        else : self.life=0
        if self.life==0:
            theGame()._hero._equip.remove(self)
            theGame().addMessage("Be careful ! Your "+self.name+" has been destroyed. ")

class Weapon(Equipment):
    def __init__(self,name,abbrv="T",usage=None,life=5,quality=1,strength=2):
        self.life=life
        self.quality=quality
        self.strength=strength
        Equipment.__init__(self,name,abbrv,usage)

    def useWeapon(self,used=[]):
        used.append(1)
        if sum(used)==self.life:
            theGame()._hero._equip.remove(self)
            theGame().addMessage("Be careful ! Your "+self.name+" has been destroyed. ")


class Game(object):
    """ Class representing game state """

    """ available equipments """
    equipments = {0: [Equipment("potion", "!", usage=lambda self, hero: heal(hero)), \
                      Equipment("gold", "o")], \
                  1: [Equipment("gold", "o")], \
                  2: [Weapon("sword", usage=lambda self, hero: equip(hero,self)),Equipment("gold", "o")], \
                  3: [Equipment("portoloin", "w", usage=lambda self, hero: teleport(hero, False)),Weapon("axe","X",quality=2,usage=lambda self, hero:equip(hero,self)),Equipment("gold", "o")], \
                  4:[Armor("armor","A", usage=lambda self, hero: equip(hero,equipment=self)),Equipment("gold", "o"), \
                    Armor("Silver Armor",quality=2,usage=lambda self, hero:equip(hero,self)),Equipment("antidote","a",usage=lambda self, hero : antidote(hero))],\
                  5:[Armor("Golden Armor",quality=3,usage=lambda self,hero:equip(hero,self)),Weapon("Battle Axe",quality=3,usage=lambda self,hero:equip(hero,self))],\
                  8:[Weapon("Blessed Blade",quality=4,usage=lambda self,hero:equip(hero,self))]
                  }
    """ available monsters """
    monsters = {0: [Creature("Goblin", 10, XP=2), Creature("Brunch", 5, "W",XP=1)],
                1: [Creature("Ork", 12, strength=2,XP=5), Creature("Blob", 15,XP=8)], 5: [Creature("Dragon", 25, strength=3,XP=15)],6:[Creature("Super Spider", 25,strength=5,XP=17),Creature("Gnoll",10,strength=15,XP=17)]}

    "list of objects you can buy"
    equipmentsList=[Equipment("potion", "!", usage=lambda self, hero: heal(hero)),Equipment("portoloin","w", usage=lambda self, hero: teleport(hero, False)),\
        Equipment("antidote","a",usage=lambda self, hero: teleport(hero, True)),Weapon("sword", usage=lambda self, hero: equip(hero,self)),\
        Weapon("axe","X",quality=2,usage=lambda self, hero:equip(hero,self)),Armor("armor","A", usage=lambda self, hero: equip(hero,equipment=self)),\
        Armor("Silver Armor",quality=2,usage=lambda self, hero:equip(hero,self)),Armor("Golden Armor",quality=3,usage=lambda self,hero:equip(hero,self)),\
        Weapon("Battle Axe",quality=3,usage=lambda self,hero:equip(hero,self)),Weapon("Blessed Blade",quality=4,usage=lambda self,hero:equip(hero,self))]
    equipmentsPrices=[2,4,2,4,6,5,7,10,10,15]
    
    """ available actions """
    _actions = {'z': lambda h: theGame()._floor.move(h, Coord(0, -1)), \
                'q': lambda h: theGame()._floor.move(h, Coord(-1, 0)), \
                's': lambda h: theGame()._floor.move(h, Coord(0, 1)), \
                'd': lambda h: theGame()._floor.move(h, Coord(1, 0)), \
                'i': lambda h: theGame().addMessage(h.fullDescription()), \
                'k': lambda h: h.__setattr__('hp', 0), \
                'u': lambda h: h.use(theGame().selectInvent(h._inventory)), \
                ' ': lambda h: None, \
                'h': lambda hero: theGame().addMessage("Actions disponibles : " + str(list(Game._actions.keys()))), \
                'b': lambda hero: theGame().addMessage("I am " + hero.name), \
                'x': lambda h: h._inventory.remove(theGame().selectInvent(h._inventory)), #permet de détruire un equipement
                'e': lambda h: theGame()._floor.move(h, Coord(1, -1)), #diagonale haut droite
                'a': lambda h: theGame()._floor.move(h, Coord(-1, -1)), #diagonale haut gauche
                'w': lambda h: theGame()._floor.move(h, Coord(-1, 1)),
                'c': lambda h: theGame()._floor.move(h, Coord(1, 1))}

    def __init__(self, level=1, hero=None):
        self._level = level
        self._messages = []
        if hero == None:
            hero = Hero()
        self._hero = hero
        self._floor = None


    def buildFloor(self):
        """Creates a map for the current floor."""
        self.plcmt=[]
        for i in range(400):
            self.plcmt.append(random.randint(0,11))
        self._floor = Map(hero=self._hero)
        while len(self._floor._mat)==1:
            self._floor = Map(hero=self._hero)
        self._floor.put(self._floor._rooms[-1].center(), Stairs())
        self._level += 1
    
    def buildFloorShop(self):
        """Creates a map for the current floor with a shop in the middle."""
        self._floor = Map(size=20,hero=self._hero,deco=True)
        self._floor.put(self._floor._rooms[-1].center(), Shopping("S"))
        self._floor.put(self._floor._rooms[-1].randCoord(), Stairs())
        self._level += 1

    def addMessage(self, msg):
        """Adds a message in the message list."""
        self._messages.append(msg)

    def readMessages(self):
        """Returns the message list and clears it."""
        s = ''
        for m in self._messages:
            s += m 
        self._messages.clear()
        return s

    def randElement(self, collect):
        """Returns a clone of random element from a collection using exponential random law."""
        x = random.expovariate(1 / self._level)
        for k in collect.keys():
            if k <= x:
                l = collect[k]
        return copy.copy(random.choice(l))

    def randEquipment(self):
        """Returns a random equipment."""
        return self.randElement(Game.equipments) 

    def randMonster(self):
        """Returns a random monster."""
        return self.randElement(Game.monsters)

    def selectShop(self, l):
        key="0123456789"
        des.AffShop()
        for i in key:
            des.fenetre.bind(i,useShop)
        return None

    def selectInvent(self, l):
        key="0123456789"
        for i in key:
            des.fenetre.bind(i,useInvent)
        return None

class Drawing(object):
    "interface graphique" 
    def __init__(self):
        #créer une fenêtre tkinter
        self.fenetre=Tk()
        #créer la toile sur laquelle on dessine  
        self.canvas = Canvas(self.fenetre, bg="dark grey", height=840, width=1160)
        #repertorie par utilisation les images correspondant à chaque objet
        self.sol=[PhotoImage(file="cobble_blood1.png"),PhotoImage(file="cobble_blood2.png"),PhotoImage(file="cobble_blood3.png"),PhotoImage(file="cobble_blood4.png"),PhotoImage(file="cobble_blood5.png"),PhotoImage(file="cobble_blood6.png"),PhotoImage(file="cobble_blood7.png"),PhotoImage(file="cobble_blood8.png"),PhotoImage(file="cobble_blood9.png"),PhotoImage(file="cobble_blood10.png"),PhotoImage(file="cobble_blood11.png"),PhotoImage(file="cobble_blood12.png")]
        self.picsM={theGame()._hero.name: PhotoImage(file="images\dc-mon\centaur.png"), "Goblin": PhotoImage(file="images\dc-mon\goblin.png"), "Brunch": PhotoImage(file="images\dc-mon\shining_eye.png"),"Ork": PhotoImage(file="images\dc-mon/titan.png"),"Blob":PhotoImage(file="images\dc-mon\jelly.png"),"Dragon": PhotoImage(file="images\dc-mon\shadow_dragon.png"),"Super Spider":PhotoImage(file="images\dc-mon/animals/redback.png"),"Gnoll":PhotoImage(file="images\dc-mon\gnoll.png")}
        self.picsO={"potion": PhotoImage(file="images\item\potion\cyan.png"),"antidote": PhotoImage(file="emerald.png"),"gold":PhotoImage(file="images\item/ring\gold.png"),\
            "sword": PhotoImage(file="images\item\weapon\orcish_great_sword.png"),"portoloin": PhotoImage(file="images\item\weapon\holy_scourge.png"),\
            "armor":PhotoImage(file="images\item/armour\elven_scalemail.png"),"Silver Armor":PhotoImage(file="images\item/armour\chain_mail1.png"),\
            "axe":PhotoImage(file="images\item\weapon/broad_axe3.png"),"Golden Armor":PhotoImage(file="images\item/armour\gold_dragon_armour.png"),\
            "Battle Axe":PhotoImage(file="images\item\weapon/battle_axe3.png"),"Blessed Blade":PhotoImage(file="images\item\weapon/blessed_blade.png")}
        self.stairsImage=PhotoImage(file="stone_stairs_up.png")
        self.welcomeImage={"bg":PhotoImage(file="welcome3.png"),"play":PhotoImage(file="press_start.png"),"exit":PhotoImage(file="exit.png")}
        self.welcomeButton={"play":Button(self.fenetre,borderwidth=0,activebackground="black",background="black",highlightthickness=0,image=self.welcomeImage["play"], command=play),"exit":Button(self.fenetre,borderwidth=0,activebackground="black",background="black",highlightthickness=0,image=self.welcomeImage["exit"], command=close_window)}
        self.inventaire={"inventory":PhotoImage(file="inventaire.png"),"bg": PhotoImage(file="fond_inventaire.png")}
        self.hp=PhotoImage(file="heart.png")
        self.poison=PhotoImage(file="images/UNUSED/spells/agony.png")
        self.msg=PhotoImage(file="fond_msg.png")
        self.backIm=PhotoImage(file="backmap.png")
        self.gameOver=PhotoImage(file="welcome2.png")
        self.gameOverButton={"quit":Button(self.fenetre,borderwidth=0,activebackground="black",background="black",highlightthickness=0,image=self.welcomeImage["exit"], command=close_window),\
            "play":Button(self.fenetre,borderwidth=0,activebackground="black",background="black",highlightthickness=0,image=self.welcomeImage["play"], command=replay)}
        self.shop={"shop":PhotoImage(file="images\dc-dngn\shops\dngn_enter_shop.png"),"seller":PhotoImage(file="images\dc-mon\wizard.png"),1:PhotoImage(file="prix1.png"),\
            2: PhotoImage(file="prix2.png"),4:PhotoImage(file="prix4.png"),5:PhotoImage(file="prix5.png"),6:PhotoImage(file="prix6.png"),7:PhotoImage(file="prix7.png"),\
            10: PhotoImage(file="prix10.png"),15:PhotoImage(file="prix15.png")}

    def drawMap(self):
        #affiche le jeu
        nb=0
        y=0
        des.canvas.delete("all")
        if theGame()._hero.hp<=0:
            #affiche la page "game over"
            self.canvas.create_image(0,0,anchor=NW,image=self.gameOver)
            self.canvas.create_window(447.5,400,anchor=NW,window=self.gameOverButton["play"])
            self.canvas.create_window(450,600,anchor=NW,window=self.gameOverButton["quit"])
        else :
            #parcourt la matrice de l'étage et dessine chaque élément
            self.canvas.create_image(0,0,anchor=NW,image=self.backIm)
            for i in theGame()._floor._mat:
                y+=32
                x=0
                for j in i:
                    x+=32
                    if j!=" ":
                        self.canvas.create_image(x,y,anchor=NW,image=self.sol[theGame().plcmt[nb]])
                    if type(j)==Creature or type(j)==Hero:
                        self.canvas.create_image(x,y,anchor=NW,image=self.picsM[j.name])
                    elif type(j)==Equipment or type(j)==Armor or type(j)==Weapon:
                        self.canvas.create_image(x,y,anchor=NW,image=self.picsO[j.name])
                    elif type(j)==Stairs:
                        self.canvas.create_image(x,y,anchor=NW,image=self.stairsImage)
                    elif type(j)==Boutique:
                        self.canvas.create_image(x,y,anchor=NW,image=self.shop["shop"])
                    elif type(j)==Shopping:
                        self.canvas.create_image(x,y,anchor=NW,image=self.shop["seller"])
                    nb+=1
            #affiche les informations du héros
            self.AffInventory()
            self.AffEquipments()
            self.AffXP()
            self.Affhp()
            self.canvas.create_image(0,672,anchor=NW,image=self.msg)
            self.canvas.create_text(150,700,anchor=NW,text=theGame().readMessages(),font="Courier 20 bold")
            self.canvas.create_text(990,50,anchor=NW,text="Level "+ str(theGame()._hero._lvl),font="Courier 25 bold")
            self.canvas.create_text(970,400,anchor=NW,text="Strenght : "+str(theGame()._hero.strength), font="Courier 16 bold")
            self.AffGold()
            self.canvas.pack()
            self.fenetre.bind("<Key>",drawMove)

    def welcome(self):
        #affiche la page d'accueil
        self.canvas.create_image(0,0,anchor=NW,image=self.welcomeImage["bg"])
        self.canvas.create_window(447.5,400,anchor=NW,window=self.welcomeButton["play"])
        self.canvas.create_window(450,600,anchor=NW,window=self.welcomeButton["exit"])
        self.canvas.pack()
        self.fenetre.mainloop()

    def exit(self):
        exit(0) 

    def reset(self):
        #remet le niveau du jeu à 1 et construit une nouvelle carte
        theGame()._level=1
        theGame().buildFloor()

    def AffInventory(self):
        #affiche l'inventaire du héros
        self.canvas.create_image(960,0,anchor=NW,image=self.inventaire["bg"])
        y=200
        x=970
        self.canvas.create_image(x,y,anchor=NW,image=self.inventaire["inventory"])
        if len(theGame()._floor._hero._inventory)<=5:
            for i in theGame()._floor._hero._inventory:
                self.canvas.create_image(x,y,anchor=NW,image=self.picsO[i.name])
                x+=38
        else:
            l1=theGame()._floor._hero._inventory[:5]
            l2=theGame()._floor._hero._inventory[5:]
            for i in l1:
                self.canvas.create_image(x,y,anchor=NW,image=self.picsO[i.name])
                x+=38
            y+=38
            x=970
            for i in l2:
                self.canvas.create_image(x,y,anchor=NW,image=self.picsO[i.name])
                x+=38

    def AffEquipments(self):
        #affiche l'équipement du héros
        y=300
        x=970
        self.canvas.create_image(x,y,anchor=NW,image=self.inventaire["inventory"])
        if len(theGame()._floor._hero._equip)<=5:
            for i in theGame()._floor._hero._equip:
                self.canvas.create_image(x,y,anchor=NW,image=self.picsO[i.name])
                x+=38
        else:
            l1=theGame()._floor._hero._equip[:5]
            l2=theGame()._floor._hero._equip[5:]
            for i in l1:
                self.canvas.create_image(x,y,anchor=NW,image=self.picsO[i.name])
                x+=38
            y+=38
            x=970
            for i in l2:
                self.canvas.create_image(x,y,anchor=NW,image=self.picsO[i.name])
                x+=38

    def AffGold(self):
        #affiche l'or du héros
        c=len(theGame()._hero._gold)
        self.canvas.create_text(1060,473,anchor=NW,text=str(c), font="Courier 20 bold")
        self.canvas.create_image(1100,470,anchor=NW,image=self.picsO["gold"])

    def AffXP(self):
        #affiche l'expérience du héros
        x1=970
        y1=100
        x2=x1+100*theGame()._hero.XP/math.exp(theGame()._hero._lvl)
        y2=y1+20
        self.canvas.create_rectangle(x1,y1,x1+100,y2,fill="brown",outline="black")
        self.canvas.create_rectangle(x1,y1,x2,y2,fill="black",outline="black")
        self.canvas.create_text(1100,y1,anchor=NW,text="XP ",font="Courier 14 bold")
        self.canvas.pack()

    def Affhp(self):
        #affiche la santé du héros
        x1=970
        y1=150
        x2=x1+100*theGame()._hero.hp/theGame()._hero._hpMAX
        y2=y1+20
        self.canvas.create_rectangle(x1,y1,x1+100,y2,fill="brown",outline="black")
        self.canvas.create_rectangle(x1,y1,x2,y2,fill="red",outline="black")
        self.canvas.create_image(1090,y1-5,anchor=NW,image=self.hp)
        if theGame()._hero.curse :
            self.canvas.create_image(1092,y1-5,anchor=NW,image=self.poison)

        self.canvas.pack()
    def AffShop(self):
        #affiche les objets que l'on peut acheter et leur prix lorsque l'on rencontre le vendeur
        x=300
        for i in theGame().equipmentsList:
            y=700
            self.canvas.create_image(x,y,anchor=NW,image=self.picsO[i.name])
            y+=40
            self.canvas.create_image(x,y,anchor=NW,image=self.shop[theGame().equipmentsPrices[theGame().equipmentsList.index(i)]])
            x+=60 
        self.canvas.pack()
        #associe les touches aux objets pour pouvoir les sélectionner en faisant appel à useShop
        key="0123456789"
        for i in key:
            self.fenetre.bind(i,useShop)
        self.fenetre.mainloop()
    
    def replay(self):
        #réinitialise le héros et l'étage du jeu
        theGame()._floor._hero=Hero()
        theGame()._hero=theGame()._floor._hero
        self.reset()
        des.drawMap()

def close_window():
    #ferme la fenêtre tkinter
    des.fenetre.destroy()

def play():
    #lance le jeu
    des.drawMap()

def replay():
    #relance le jeu
    des.replay()

def useShop(event):
    #sélectionne l'object() en fonction de la touche appuyée
        choix=theGame().equipmentsList[int(event.char)]
        if len(theGame()._hero._gold)>=theGame().equipmentsPrices[int(event.char)]:
            #vérifie que la quantité d'or soit suffisante et réalise l'achat ou non
            for i in range(theGame().equipmentsPrices[int(event.char)]):
               theGame()._hero._gold.pop(0)
            theGame()._hero.take(theGame().equipmentsList[int(event.char)])
            theGame().addMessage("Good choice ! See you soon")
        else:
            theGame().addMessage("Sorry ! I can't help you, you don't have enough gold")
        des.drawMap()

def useInvent(event):
    #sélectionne un objet dans l'inventaire suivant la touche appuyée
    if int(event.char) <len(theGame()._hero._inventory):
        theGame()._hero.use(theGame()._hero._inventory[int(event.char)])
        des.drawMap()

def drawMove(event):
    #redessine la Map à chaque action du héros
    if event.char in theGame()._actions:
        theGame()._actions[event.char](theGame()._hero)
        if theGame()._hero.curse:
            theGame()._hero.hp-=1
        print(theGame()._floor)
        if event.char!="u" and event.char!="k":
            theGame()._floor.moveAllMonsters()
            des.drawMap()
        if event.char=="k":
            des.drawMap()

def theGame(game=Game()):
    """Game singleton"""
    return game

theGame().buildFloor()
print(theGame()._floor)
des=Drawing()
des.welcome()
